
require('./db')
const express = require('express')
const app = express()

app.use(express.urlencoded({extended: true}))
app.use(express.json())

const {PORT} = require('./config')

const printer = require('./routes/printer')
const user = require('./routes/user')

app.use('/api/v1/printer',printer)
app.use('/api/v1/user',user)

app.listen(PORT, () => console.log('Api Server is Running!'))
    