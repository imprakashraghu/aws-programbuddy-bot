
const mongoose = require('mongoose')
const {DATABASE_URL} = require('../config')

mongoose
  .connect(DATABASE_URL, { useNewUrlParser: true, socketTimeoutMS: 30000, keepAlive: true })
  .then(() => console.log('Database Connected'))
  .catch((error) => console.log(error))

module.exports = mongoose
    