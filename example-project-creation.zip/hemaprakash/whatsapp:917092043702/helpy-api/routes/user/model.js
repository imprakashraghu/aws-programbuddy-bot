const mongoose = require('mongoose')
const userSchema = new mongoose.Schema({
  "Age": {
    "type": "String"
  },
  "FirstName": {
    "type": "String"
  },
  "LastName": {
    "type": "String"
  },
  "Phone": {
    "type": "String"
  }
},{timestamps: true,})
module.exports = mongoose.model('user', userSchema)