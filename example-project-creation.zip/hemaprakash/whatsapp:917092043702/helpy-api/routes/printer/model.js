const mongoose = require('mongoose')
const printerSchema = new mongoose.Schema({
  "Name": {
    "type": "String"
  },
  "Owner": {
    "type": "String"
  },
  "Price": {
    "type": "String"
  },
  "Type": {
    "type": "String"
  }
},{timestamps: true,})
module.exports = mongoose.model('printer', printerSchema)