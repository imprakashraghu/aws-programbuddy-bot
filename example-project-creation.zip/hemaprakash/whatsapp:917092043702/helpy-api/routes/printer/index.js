
'use strict'
const router = require('express').Router()
const printerModel = require('./model')

// READ ALL USER
router.get('/', async (req, res) => {
    try {
         
        const users = await userModel.find({},{__v: 0})
        res.status(200).send(users)

    } catch (err) {
        res.status(500).json({status: false, message: 'Internal Server Error', error: err.message || null})
    }
})
// CREATE USER
router.post('/', async (req, res) => {
    try {

        // EVERYTHING CANNOT BE NULL
        if (!req.body.Name || !req.body.Type || !req.body.Price || !req.body.Owner) {
            return res.status(400).json({status: false, message: 'Parameters Missing!'})
        }

        const printerCreationPayload = {
            Name: req.body.Name,
Type: req.body.Type,
Price: req.body.Price,
Owner: req.body.Owner
        }

        const printer = new printerModel(printerCreationPayload)
        printer.save((err, doc) => {
            if (err) {
                res.status(500).json({status: false, message: 'Internal Server Error', error: err.message || null})
            }
            res.status(200).json({status: true, message: "printer Created Successfully", data: doc})
        })

    } catch (err) {
        res.status(500).json({status: false, message: 'Internal Server Error', error: err.message || null})
    }
})
// UPDATE USER
router.put('/:id', async (req, res) => {
    try {
        // EVERYTHING CANNOT BE NULL
        if (!req.body.Name || !req.body.Type || !req.body.Price || !req.body.Owner) {
            return res.status(400).json({status: false, message: 'Parameters Missing!'})
        }

        let printerUpdatePayload = {
            Name: req.body.Name,
Type: req.body.Type,
Price: req.body.Price,
Owner: req.body.Owner
        }

        await printerModel.findByIdAndUpdate(req.params.id, {
            $set: printerUpdatePayload,
        })

        res.status(200).json({status: true, message: 'printer Updated Successfully'})

    } catch (err) {
        res.status(500).json({status: false, message: 'Internal Server Error', error: err.message || null})
    }
})
// DELETE USER
router.delete('/:id', async (req, res) => {
    try {

        await printerModel.findByIdAndDelete(req.params.id)

        res.status(200).json({status: true, message: 'printer Deleted Successfully'})
        
    } catch (err) {
        res.status(500).json({status: false, message: 'Internal Server Error', error: err.message || null})
    }
})

module.exports = router
    